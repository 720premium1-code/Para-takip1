MONEY TALKS - güncellenmiş web uygulaması dosyaları

Dosyalar:
- index.html : Android APK içinde kullanılacak tam uygulama
- app-index.html : GitHub Pages / web sürümü için aynı uygulamanın kopyası
- AndroidManifest.xml : Android uygulama adını Money Talks yapar

GitHub deposunda şu dosyaları değiştir:
1) app/src/main/assets/index.html dosyasının içeriğini index.html dosyasındaki içerikle değiştir.
2) Depo kökündeki index.html dosyasının içeriğini app-index.html dosyasındaki içerikle değiştir.
3) app/src/main/AndroidManifest.xml dosyasının içeriğini AndroidManifest.xml dosyasındaki içerikle değiştir.
Sonra GitHub Actions > Build APK iş akışını çalıştır. APK derlenince Artifacts bölümünden indir.

Not: Yeni sürüm TL ve Euro bakiyelerini ayrı gösterir; her işlemde işlem tutarı, TL karşılığı ve Euro karşılığı bulunur. Euro kuru Ayarlar bölümünden düzenlenir. Eski Para Takip kayıtlarını ilk açılışta tanımaya çalışır; önemli kayıtların varsa önce eski uygulamadan yedek al.
